"""ScoutOut MCP server."""
